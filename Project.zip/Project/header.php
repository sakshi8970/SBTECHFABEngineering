<?php
/**
 * ==========================================================================
 * M-TECH ENGINEERING | GLOBAL HEADER
 * ==========================================================================
 * Include at the top of every page:
 *   $pageTitle = 'Home'; // set before including
 *   require_once __DIR__ . '/header.php';
 * ==========================================================================
 */
$pageTitle = $pageTitle ?? 'Home';
$siteName  = 'M-Tech Engineering';
$tagline   = 'Precision Sheet Metal Fabrication & Advanced Manufacturing Solutions';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo htmlspecialchars($pageTitle); ?> | M-Tech Engineering - Precision Manufacturing</title>
<meta name="description" content="<?php echo htmlspecialchars($tagline); ?>">

<!-- Favicon -->
<link rel="icon" type="image/png" href="assets/images/favicon.png">

<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Source+Serif+4:opsz,wght@8..60,500;8..60,600;8..60,700&display=swap" rel="stylesheet">

<!-- Styles -->
<link rel="stylesheet" href="style.css">

</head>
<body>

<!-- ======================= TOP CONTACT BAR ======================= -->
<div class="top-bar">
  <div class="container top-bar-inner">
    <div class="top-bar-contacts">
      <a href="tel:+911234567890"><span aria-hidden="true">&#9742;</span> +91 12345 67890</a>
      <a href="mailto:info@mtechengineering.com"><span aria-hidden="true">&#9993;</span> info@mtechengineering.com</a>
    </div>
    <div class="top-bar-meta">
      <span>Mon&ndash;Sat, 9:00&ndash;18:00</span>
      <a href="rfq.php" class="top-bar-cta">Request a Quote</a>
    </div>
  </div>
</div>

<!-- ======================= STICKY NAVBAR ======================= -->
<header class="site-header" id="siteHeader">
  <div class="container site-header-inner">
    <a href="index.php" class="brand">
      <img src="assets/images/favicon.png" alt="M-Tech Engineering logo" class="brand-mark" onerror="this.style.display='none'">
      <span class="brand-text">
        <span class="brand-name">M-Tech Engineering</span>
        <span class="brand-tagline">Precision Manufacturing</span>
      </span>
    </a>

    <button class="nav-toggle" id="navToggle" aria-expanded="false" aria-controls="primaryNav" aria-label="Toggle navigation menu">
      <span></span><span></span><span></span>
    </button>

    <nav class="primary-nav" id="primaryNav">
      <ul class="nav-list">
        <li class="nav-item"><a href="index.php">Home</a></li>
        <li class="nav-item"><a href="about.php">About Us</a></li>

        <li class="nav-item has-dropdown">
          <a href="services.php" class="nav-link-toggle">Services <span class="caret" aria-hidden="true">&#9662;</span></a>
          <ul class="dropdown-menu">
            <li><a href="services.php#laser-cutting">Laser Cutting</a></li>
            <li><a href="services.php#cnc-press-braking">CNC Press Braking</a></li>
            <li><a href="services.php#robotic-welding">Robotic Welding</a></li>
            <li><a href="services.php#powder-coating">Powder Coating</a></li>
            <li><a href="services.php#sheet-metal-fabrication">Sheet Metal Fabrication</a></li>
            <li><a href="services.php#tool-die-manufacturing">Tool &amp; Die Manufacturing</a></li>
          </ul>
        </li>

        <li class="nav-item has-dropdown">
          <a href="products.php" class="nav-link-toggle">Products <span class="caret" aria-hidden="true">&#9662;</span></a>
          <ul class="dropdown-menu">
            <li><a href="products.php?category=defence">Defence</a></li>
            <li><a href="products.php?category=automobile">Automobile</a></li>
            <li><a href="products.php?category=solar">Solar</a></li>
            <li><a href="products.php?category=storage">Storage</a></li>
          </ul>
        </li>

        <li class="nav-item"><a href="quality.php">Quality &amp; Infrastructure</a></li>
        <li class="nav-item"><a href="contact.php">Contact</a></li>
      </ul>

      <a href="rfq.php" class="btn btn-saffron nav-cta">Get a Quote</a>
    </nav>
  </div>
</header>
