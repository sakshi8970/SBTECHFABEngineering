// ==========================================================================
// M-TECH ENGINEERING | MAIN.JS
// ==========================================================================
// All interactive behaviour for the site lives in this single file,
// organized into clearly labeled sections below.
// ==========================================================================

document.addEventListener('DOMContentLoaded', function () {

  // ==========================================================================
  // 01. NAVIGATION DROPDOWNS & MOBILE ACCORDION LOGIC
  // ==========================================================================
  (function initNavigation() {
    var navToggle = document.getElementById('navToggle');
    var primaryNav = document.getElementById('primaryNav');
    var dropdownParents = document.querySelectorAll('.nav-item.has-dropdown');
    var MOBILE_BREAKPOINT = 992;

    if (navToggle && primaryNav) {
      navToggle.addEventListener('click', function () {
        var isOpen = primaryNav.classList.toggle('is-open');
        navToggle.classList.toggle('is-active', isOpen);
        navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      });
    }

    dropdownParents.forEach(function (item) {
      var toggleLink = item.querySelector('.nav-link-toggle');
      if (!toggleLink) return;

      toggleLink.addEventListener('click', function (e) {
        // On mobile, clicking the parent link toggles the accordion
        // instead of navigating away, since sub-items are reachable below.
        if (window.innerWidth < MOBILE_BREAKPOINT) {
          e.preventDefault();
          var isOpen = item.classList.toggle('is-open');

          // Close sibling accordions for a cleaner single-open experience.
          dropdownParents.forEach(function (other) {
            if (other !== item) other.classList.remove('is-open');
          });

          toggleLink.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        }
      });
    });

    // Close the mobile menu when a plain (non-dropdown) link is tapped.
    primaryNav && primaryNav.querySelectorAll('.nav-item > a:not(.nav-link-toggle), .nav-cta').forEach(function (link) {
      link.addEventListener('click', function () {
        if (window.innerWidth < MOBILE_BREAKPOINT) {
          primaryNav.classList.remove('is-open');
          navToggle && navToggle.classList.remove('is-active');
          navToggle && navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });

    // Reset mobile-only state if the viewport is resized back to desktop.
    window.addEventListener('resize', function () {
      if (window.innerWidth >= MOBILE_BREAKPOINT) {
        primaryNav && primaryNav.classList.remove('is-open');
        navToggle && navToggle.classList.remove('is-active');
        dropdownParents.forEach(function (item) { item.classList.remove('is-open'); });
      }
    });
  })();

  // ==========================================================================
  // 02. DYNAMIC COUNTER LOGIC (INTERSECTION OBSERVER)
  // ==========================================================================
  (function initCounters() {
    var counters = document.querySelectorAll('.counter-number');
    if (!counters.length) return;

    var DURATION = 1600; // ms

    function animateCounter(el) {
      var target = parseInt(el.getAttribute('data-target'), 10) || 0;
      var startTime = null;

      function step(timestamp) {
        if (startTime === null) startTime = timestamp;
        var progress = Math.min((timestamp - startTime) / DURATION, 1);
        // Ease-out for a natural deceleration toward the target value.
        var eased = 1 - Math.pow(1 - progress, 3);
        var current = Math.floor(eased * target);
        el.textContent = current.toLocaleString();

        if (progress < 1) {
          window.requestAnimationFrame(step);
        } else {
          el.textContent = target.toLocaleString();
        }
      }

      window.requestAnimationFrame(step);
    }

    if (!('IntersectionObserver' in window)) {
      counters.forEach(animateCounter);
      return;
    }

    var observer = new IntersectionObserver(function (entries, obs) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          animateCounter(entry.target);
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.4 });

    counters.forEach(function (el) { observer.observe(el); });
  })();

  // ==========================================================================
  // 03. INTERACTIVE PRODUCT & SERVICE FILTER SYSTEM
  // ==========================================================================
  (function initProductFilters() {
    var filterButtons = document.querySelectorAll('.filter-btn');
    var productCards = document.querySelectorAll('.product-card');
    var emptyState = document.getElementById('productsEmpty');
    if (!filterButtons.length || !productCards.length) return;

    filterButtons.forEach(function (button) {
      button.addEventListener('click', function () {
        var filter = button.getAttribute('data-filter');

        filterButtons.forEach(function (b) { b.classList.remove('is-active'); });
        button.classList.add('is-active');

        var visibleCount = 0;

        productCards.forEach(function (card) {
          var matches = filter === 'all' || card.getAttribute('data-category') === filter;
          card.style.display = matches ? '' : 'none';
          if (matches) visibleCount++;
        });

        if (emptyState) {
          emptyState.hidden = visibleCount !== 0;
        }
      });
    });
  })();

  // ==========================================================================
  // 04. HERO & CLIENT SWIPER SLIDER INITIALIZATION
  // ==========================================================================
  (function initHeroSlider() {
    var slides = document.querySelectorAll('.hero-slide');
    var dots = document.querySelectorAll('.hero-dot');
    if (!slides.length) return;

    var currentIndex = 0;
    var AUTOPLAY_INTERVAL = 6000;
    var timer = null;

    function showSlide(index) {
      slides.forEach(function (slide, i) {
        slide.classList.toggle('is-active', i === index);
      });
      dots.forEach(function (dot, i) {
        dot.classList.toggle('is-active', i === index);
      });
      currentIndex = index;
    }

    function nextSlide() {
      showSlide((currentIndex + 1) % slides.length);
    }

    function startAutoplay() {
      stopAutoplay();
      timer = window.setInterval(nextSlide, AUTOPLAY_INTERVAL);
    }

    function stopAutoplay() {
      if (timer) window.clearInterval(timer);
    }

    dots.forEach(function (dot, i) {
      dot.addEventListener('click', function () {
        showSlide(i);
        startAutoplay(); // restart the timer after manual navigation
      });
    });

    var heroSection = document.getElementById('hero');
    if (heroSection) {
      heroSection.addEventListener('mouseenter', stopAutoplay);
      heroSection.addEventListener('mouseleave', startAutoplay);
    }

    startAutoplay();
  })();

  // --------------------------------------------------------------------------
  // Client logo marquee: pause the CSS animation on hover for readability.
  // --------------------------------------------------------------------------
  (function initClientMarquee() {
    var track = document.getElementById('clientsTrack');
    if (!track) return;
    track.addEventListener('mouseenter', function () { track.style.animationPlayState = 'paused'; });
    track.addEventListener('mouseleave', function () { track.style.animationPlayState = 'running'; });
  })();

  // --------------------------------------------------------------------------
  // Scroll-to-top button visibility and behaviour.
  // --------------------------------------------------------------------------
  (function initScrollTop() {
    var btn = document.getElementById('scrollTopBtn');
    if (!btn) return;

    window.addEventListener('scroll', function () {
      btn.classList.toggle('is-visible', window.scrollY > 500);
    });

    btn.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  })();

  // --------------------------------------------------------------------------
  // RFQ form: drag/drop + click file picker, and AJAX submission handling.
  // --------------------------------------------------------------------------
  (function initRfqForm() {
    var form = document.getElementById('rfqForm');
    if (!form) return;

    var fileDrop = document.getElementById('fileDrop');
    var fileInput = document.getElementById('drawingFile');
    var fileNameLabel = document.getElementById('fileDropFilename');
    var statusBox = document.getElementById('formStatus');
    var submitBtn = document.getElementById('rfqSubmitBtn');

    if (fileDrop && fileInput) {
      fileDrop.addEventListener('click', function () { fileInput.click(); });

      ['dragenter', 'dragover'].forEach(function (evt) {
        fileDrop.addEventListener(evt, function (e) {
          e.preventDefault();
          fileDrop.classList.add('is-dragover');
        });
      });

      ['dragleave', 'drop'].forEach(function (evt) {
        fileDrop.addEventListener(evt, function (e) {
          e.preventDefault();
          fileDrop.classList.remove('is-dragover');
        });
      });

      fileDrop.addEventListener('drop', function (e) {
        if (e.dataTransfer.files.length) {
          fileInput.files = e.dataTransfer.files;
          updateFileLabel();
        }
      });

      fileInput.addEventListener('change', updateFileLabel);
    }

    function updateFileLabel() {
      if (fileInput.files.length && fileNameLabel) {
        fileNameLabel.textContent = fileInput.files[0].name;
      }
    }

    function showStatus(message, isSuccess) {
      if (!statusBox) return;
      statusBox.textContent = message;
      statusBox.classList.remove('is-success', 'is-error');
      statusBox.classList.add(isSuccess ? 'is-success' : 'is-error');
    }

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Submitting...'; }

      var formData = new FormData(form);

      fetch('process_rfq.php', { method: 'POST', body: formData })
        .then(function (res) { return res.json(); })
        .then(function (data) {
          if (data.success) {
            showStatus(data.message, true);
            form.reset();
            if (fileNameLabel) fileNameLabel.textContent = '';
          } else {
            var msg = data.errors && data.errors.length ? data.errors.join(' ') : data.message;
            showStatus(msg, false);
          }
        })
        .catch(function () {
          showStatus('A network error occurred. Please try again.', false);
        })
        .finally(function () {
          if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Submit Request'; }
        });
    });
  })();

});
