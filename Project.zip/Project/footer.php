<?php
/**
 * ==========================================================================
 * M-TECH ENGINEERING | GLOBAL FOOTER
 * ==========================================================================
 * Include at the bottom of every page:
 *   require_once __DIR__ . '/footer.php';
 * ==========================================================================
 */
$currentYear = date('Y');
$whatsappNumber = '911234567890'; // international format, no + or spaces
?>
  <!-- ======================= FOOTER ======================= -->
  <footer class="site-footer">
    <div class="container footer-grid">

      <div class="footer-col footer-about">
        <a href="index.php" class="brand brand-footer">
          <img src="assets/images/favicon.png" alt="M-Tech Engineering logo" class="brand-mark" onerror="this.style.display='none'">
          <span class="brand-name">M-Tech Engineering</span>
        </a>
        <p>Precision sheet metal fabrication and advanced manufacturing solutions for defence, automobile, solar and industrial storage sectors.</p>
        <ul class="footer-contact-list">
          <li>
            <a href="tel:+911234567890" style="color: inherit; text-decoration: none;">
              <span aria-hidden="true">&#9742;</span> +91 12345 67890
            </a>
          </li>
          <li>
            <a href="mailto:info@mtechengineering.com" style="color: inherit; text-decoration: none;">
              <span aria-hidden="true">&#9993;</span> info@mtechengineering.com
            </a>
          </li>
          <li>
            <a href="https://maps.google.com/?q=Plot+14,+Industrial+Estate,+Pune,+Maharashtra,+India" target="_blank" rel="noopener" style="color: inherit; text-decoration: none;">
              <span aria-hidden="true">&#9737;</span> Plot 14, Industrial Estate, Pune, Maharashtra, India
            </a>
          </li>
        </ul>
      </div>

      <div class="footer-col">
        <h3>Quick Links</h3>
        <ul class="footer-links">
          <li><a href="index.php">Home</a></li>
          <li><a href="about.php">About Us</a></li>
          <li><a href="services.php">Services</a></li>
          <li><a href="products.php">Products</a></li>
          <li><a href="quality.php">Quality &amp; Infrastructure</a></li>
          <li><a href="contact.php">Contact</a></li>
        </ul>
      </div>

      <div class="footer-col">
        <h3>Industries Served</h3>
        <ul class="footer-links">
          <li><a href="products.php?category=defence">Defence</a></li>
          <li><a href="products.php?category=automobile">Automobile</a></li>
          <li><a href="products.php?category=solar">Solar</a></li>
          <li><a href="products.php?category=storage">Storage &amp; Warehousing</a></li>
        </ul>
      </div>

      <div class="footer-col footer-cta-col">
        <h3>Start a Project</h3>
        <p>Share your drawings and specifications — our engineering team responds within one business day.</p>
        <a href="rfq.php" class="btn btn-outline-light">Request a Quote</a>
      </div>

    </div>

    <div class="footer-bottom">
      <div class="container footer-bottom-inner">
        <p>&copy; <?php echo htmlspecialchars($currentYear); ?> M-Tech Engineering. All rights reserved.</p>
        <p class="footer-legal-links">
          <a href="privacy.php">Privacy Policy</a>
          <span aria-hidden="true">&middot;</span>
          <a href="terms.php">Terms of Service</a>
        </p>
      </div>
    </div>
  </footer>

  <!-- ======================= FLOATING WHATSAPP ICON ======================= -->
  <a href="https://wa.me/<?php echo htmlspecialchars($whatsappNumber); ?>?text=Hi%20M-Tech%20Engineering%2C%20I%27d%20like%20to%20request%20a%20quote."
     class="whatsapp-float" target="_blank" rel="noopener" aria-label="Chat with us on WhatsApp">
    <svg viewBox="0 0 32 32" width="28" height="28" aria-hidden="true" focusable="false">
      <path fill="currentColor" d="M16.02 3C9.39 3 4 8.37 4 15c0 2.34.68 4.53 1.85 6.38L4 29l7.8-1.8A11.9 11.9 0 0 0 16.02 27C22.66 27 28 21.63 28 15S22.66 3 16.02 3Zm6.98 16.9c-.3.85-1.5 1.56-2.47 1.76-.66.14-1.52.25-4.4-.94-3.69-1.53-6.06-5.26-6.24-5.5-.18-.24-1.5-2-1.5-3.8 0-1.8.94-2.7 1.28-3.06.3-.33.66-.4.88-.4h.63c.2 0 .47-.03.72.55.3.7 1 2.42 1.09 2.6.09.18.15.4.03.64-.12.24-.18.4-.36.6-.18.2-.38.46-.55.62-.18.18-.37.37-.16.72.2.36.9 1.48 1.93 2.4 1.33 1.18 2.44 1.55 2.8 1.72.36.18.57.15.78-.09.2-.24.9-1.05 1.14-1.4.24-.36.48-.3.8-.18.33.12 2.07.98 2.43 1.16.36.18.6.27.68.42.1.16.1.9-.2 1.75Z"/>
    </svg>
  </a>

  <!-- ======================= SCROLL-TO-TOP BUTTON ======================= -->
  <button class="scroll-top" id="scrollTopBtn" aria-label="Scroll back to top">&#8593;</button>

  <!-- Scripts -->
  <script src="main.js"></script>
</body>
</html>