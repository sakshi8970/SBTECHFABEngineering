<?php
/**
 * ==========================================================================
 * M-TECH ENGINEERING | ABOUT US PAGE
 * ==========================================================================
 */
declare(strict_types=1);
require_once __DIR__ . '/db_connect.php';

$pageTitle = 'About Us';
require_once __DIR__ . '/header.php';
?>

<main>

  <!-- ======================= PAGE HERO ======================= -->
  <section class="page-hero">
    <div class="container">
      <p class="hero-eyebrow">About M-Tech Engineering</p>
      <h1>Four decades of precision manufacturing.</h1>
      <p>What started as a small tool room has grown into an integrated fabrication facility trusted by OEMs across defence, automotive, solar and industrial storage — without ever losing sight of the tolerance a customer's drawing demands.</p>
    </div>
  </section>

  <!-- ======================= MISSION / STORY ======================= -->
  <section class="about-mission">
    <div class="container about-mission-grid">
      <div class="about-card-box">
        <p class="section-eyebrow">Our Story</p>
        <h2>Built on the factory floor, not the boardroom.</h2>
        <p>M-Tech Engineering began as a job-shop fabricator serving local industrial clients. Over four decades, reinvestment in equipment and process discipline turned that job-shop into a full-service manufacturing partner: laser cutting, CNC press braking, robotic welding and powder coating, all under one 11,000 sq. ft. roof.</p>
        <p>Today we supply tight-tolerance components to defence contractors, automotive tier suppliers, solar EPC firms and industrial storage manufacturers — industries where a missed tolerance or a late delivery has real consequences.</p>
      </div>
      <div class="about-card-box">
        <p class="section-eyebrow">Our Mission</p>
        <h2>Manufacturing partners choose, and stay with.</h2>
        <p>We exist to remove uncertainty from fabrication: consistent tolerances, honest lead times, and traceable quality on every batch, so our customers can design with confidence and plan their own production around ours.</p>
        <p>That mission shapes how we invest — in equipment, in our people's training, and in the QA processes documented on our <a href="quality.php" class="text-link">Quality &amp; Infrastructure</a> page.</p>
      </div>
    </div>
  </section>

  <!-- ======================= CORE VALUES ======================= -->
  <section class="container">
    <div class="section-heading">
      <p class="section-eyebrow">What Guides Us</p>
      <h2>Principles behind every batch we ship.</h2>
    </div>
  </section>
  <section class="container about-values">
    <div class="value-card">
      <h3>Precision First</h3>
      <p>Every job is measured against the drawing, not against "close enough." Tolerances are commitments, not targets.</p>
    </div>
    <div class="value-card">
      <h3>Traceable Quality</h3>
      <p>Material certificates, in-process inspection records and CMM reports travel with every batch we ship.</p>
    </div>
    <div class="value-card">
      <h3>Honest Lead Times</h3>
      <p>We quote lead times we can hold to, and we tell customers early if a schedule is at risk — not after it slips.</p>
    </div>
    <div class="value-card">
      <h3>Continuous Investment</h3>
      <p>Equipment, tooling and training are reinvested year over year, keeping pace with what our customers' designs demand.</p>
    </div>
  </section>

  <!-- ======================= COMPANY TIMELINE ======================= -->
  <section class="timeline">
    <div class="container">
      <div class="section-heading">
        <p class="section-eyebrow">Our Journey</p>
        <h2>Four decades of growth.</h2>
      </div>
      <div class="timeline-list">
        <div class="timeline-item">
          <p class="timeline-year">1980s &mdash; Founding</p>
          <p>Started as a small job-shop fabricator serving local industrial clients with manual cutting and forming equipment.</p>
        </div>
        <div class="timeline-item">
          <p class="timeline-year">1990s &mdash; First CNC Investment</p>
          <p>Introduced CNC press brakes and shears, enabling tighter tolerances and higher-volume production runs.</p>
        </div>
        <div class="timeline-item">
          <p class="timeline-year">2000s &mdash; Defence &amp; Automotive Entry</p>
          <p>Qualified as a supplier to defence and automotive OEMs, adopting formal QA documentation and material traceability.</p>
        </div>
        <div class="timeline-item">
          <p class="timeline-year">2010s &mdash; Laser Cutting &amp; Robotic Welding</p>
          <p>Added fiber laser cutting and robotic welding cells, consolidating cutting, forming and joining under one roof.</p>
        </div>
        <div class="timeline-item">
          <p class="timeline-year">2020s &mdash; Solar &amp; Storage Expansion</p>
          <p>Expanded into solar mounting structures and industrial storage racking, and moved into our current 11,000 sq. ft. facility.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- ======================= CTA BAND ======================= -->
  <section class="cta-band">
    <div class="container cta-band-inner">
      <div>
        <h2>Want to see the facility for yourself?</h2>
        <p>Get in touch to arrange a visit, or send your drawings for a quote.</p>
      </div>
      <a href="contact.php" class="btn btn-saffron">Contact Us</a>
    </div>
  </section>

</main>

<?php require_once __DIR__ . '/footer.php'; ?>