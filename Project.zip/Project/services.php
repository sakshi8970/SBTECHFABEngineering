<?php
/**
 * ==========================================================================
 * M-TECH ENGINEERING | SERVICES PAGE
 * ==========================================================================
 * Displays the complete list of fabrication services offered by M-Tech.
 * Features database integration with a structured fallback array and 
 * index-based image mapping.
 */

declare(strict_types=1);
require_once __DIR__ . '/db_connect.php';

// Set current page title
$pageTitle = 'Services';

// Fetch services from the database with error handling
try {
    $services = mtech_get_services($pdo);
} catch (Throwable $e) {
    $services = [];
}

/**
 * Fallback services dataset used when the database returns empty results
 */
$fallbackServices = [
    [
        'title'      => 'Laser Cutting',
        'slug'       => 'laser-cutting',
        'short_desc' => 'High-precision CNC fiber laser cutting up to 25mm mild steel.',
        'full_desc'  => 'Our fiber laser cutting cells hold tight tolerances across mild steel, stainless steel and aluminium, enabling fast-turnaround prototypes and high-volume production runs alike. Nested cutting programs minimise material waste while automated sheet loading keeps throughput high on repeat orders.',
        'specs'      => ['Up to 25mm mild steel', 'Up to 12mm stainless steel', '±0.1mm cut tolerance', 'Nesting software for material optimisation']
    ],
    [
        'title'      => 'CNC Press Braking',
        'slug'       => 'cnc-press-braking',
        'short_desc' => 'Multi-axis CNC bending for complex enclosures and brackets.',
        'full_desc'  => 'CNC press brakes with programmable back-gauges deliver repeatable bend angles across long production runs, supporting everything from thin-gauge panels to structural brackets. Tooling libraries cover standard and custom profiles for complex multi-bend parts.',
        'specs'      => ['Up to 6mm mild steel', 'Programmable back-gauge', '±0.5° bend angle repeatability', 'Custom tooling available']
    ],
    [
        'title'      => 'Robotic Welding',
        'slug'       => 'robotic-welding',
        'short_desc' => 'MIG/TIG and robotic welding cells for structural assemblies.',
        'full_desc'  => 'Certified welders and robotic welding cells combine to deliver consistent, code-compliant joints on both small components and large fabricated structures. Fixtures are built in-house to hold repeat geometry accurately across production runs.',
        'specs'      => ['MIG, TIG &amp; robotic cells', 'Certified welding staff', 'Custom weld fixtures', 'Structural &amp; sheet metal joints']
    ],
    [
        'title'      => 'Powder Coating',
        'slug'       => 'powder-coating',
        'short_desc' => 'In-house electrostatic powder coating and finishing line.',
        'full_desc'  => 'A dedicated pre-treatment and powder coating line provides corrosion-resistant, durable finishes in a wide range of RAL colours, with batch tracking from pre-treatment through cure.',
        'specs'      => ['Full RAL colour range', '7-tank pre-treatment process', 'Batch traceability', 'Textured &amp; gloss finishes']
    ],
    [
        'title'      => 'Sheet Metal Fabrication',
        'slug'       => 'sheet-metal-fabrication',
        'short_desc' => 'End-to-end fabrication from design to finished assembly.',
        'full_desc'  => 'From DFM review through cutting, forming, welding and finishing, we manage the full fabrication lifecycle under one roof — reducing handoffs, lead time and the risk of tolerance drift between process steps.',
        'specs'      => ['DFM review included', 'Single-facility process flow', 'Prototype to production volumes', 'Assembly &amp; sub-assembly available']
    ],
    [
        'title'      => 'Tool &amp; Die Manufacturing',
        'slug'       => 'tool-die-manufacturing',
        'short_desc' => 'Precision tooling for high-volume stamping operations.',
        'full_desc'  => 'In-house tool room capabilities support progressive and compound die design and build for demanding stamping applications, backed by preventive maintenance schedules that protect tool life.',
        'specs'      => ['Progressive &amp; compound dies', 'In-house tool room', 'Preventive maintenance program', 'Die tryout &amp; validation']
    ],
];

/**
 * Image URL mapping by numeric index to guarantee accurate image delivery
 * regardless of database slug discrepancies.
 */
$serviceImagesByIndex = [
    0 => 'https://media.gettyimages.com/id/1206070769/photo/portrait-of-an-employee-working-on-the-production-line.jpg?s=612x612&w=0&k=20&c=54nJgYmd3q36CQi1z5M2aoJxb_KjGEdgXIOWsOv9oqM=', // 1. Laser Cutting
    1 => 'https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?auto=format&fit=crop&w=800&q=80', // 2. CNC Press Braking
    2 => 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=800&q=80', // 3. Robotic Welding
    3 => 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=800&q=80', // 4. Powder Coating
    4 => 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=800&q=80', // 5. Sheet Metal Fabrication
    5 => 'https://media.gettyimages.com/id/1008939114/photo/automatic-stamping-and-bending-machine-cnc.jpg?s=612x612&w=0&k=20&c=GFtKIAJhPB9oFZBgQQ8nmZF6EMH6p-whtl4aloCv0VM='  // 6. Tool & Die Manufacturing
];

// Determine the final active dataset (database records or fallback array)
$displayServices = !empty($services) ? array_map(function ($s) {
    $s['full_desc'] = $s['full_desc'] ?? $s['short_desc'] ?? '';
    $s['specs']     = $s['specs'] ?? [];
    return $s;
}, $services) : $fallbackServices;

// Include header layout component
require_once __DIR__ . '/header.php';
?>

<main>

  <!-- ==========================================================================
       01. PAGE HERO SECTION
       ========================================================================== -->
  <section class="page-hero">
    <div class="container">
      <p class="hero-eyebrow">Our Services</p>
      <h1>Fabrication capabilities under one roof.</h1>
      <p>Cutting, forming, joining and finishing — every core process is run in-house so tolerances hold from the first cut to the final coat.</p>
    </div>
  </section>

  <!-- ==========================================================================
       02. SERVICE DETAILS SECTION
       ========================================================================== -->
  <section class="container service-detail-list">
    <?php foreach ($displayServices as $i => $service): 
      // Select image directly via loop index position, with a safety fallback URL
      $imageUrl = $serviceImagesByIndex[$i] ?? 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=800&q=80';
      $serviceSlug = $service['slug'] ?? 'service-' . ($i + 1);
    ?>
      <article class="service-detail" id="<?php echo htmlspecialchars((string)$serviceSlug); ?>">
        
        <!-- Text Content Column -->
        <div class="service-detail-text">
          <p class="section-eyebrow"><?php echo str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT); ?></p>
          <h2><?php echo htmlspecialchars($service['title']); ?></h2>
          <p><?php echo nl2br(htmlspecialchars($service['full_desc'])); ?></p>
          
          <!-- Technical Specifications Tags -->
          <?php if (!empty($service['specs'])): ?>
            <div class="service-detail-specs">
              <?php foreach ($service['specs'] as $spec): ?>
                <span class="spec-chip"><?php echo htmlspecialchars($spec); ?></span>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
          
          <p style="margin-top:22px;">
            <a href="rfq.php" class="text-link">Request a quote for this process &rarr;</a>
          </p>
        </div>

        <!-- Media Column -->
        <div class="service-detail-media">
          <img src="<?php echo htmlspecialchars($imageUrl); ?>" 
               alt="<?php echo htmlspecialchars($service['title']); ?> at M-Tech Engineering" 
               loading="lazy">
        </div>

      </article>
    <?php endforeach; ?>
  </section>

  <!-- ==========================================================================
       03. CALL TO ACTION (CTA) BAND
       ========================================================================== -->
  <section class="cta-band">
    <div class="container cta-band-inner">
      <div>
        <h2>Not sure which process fits your part?</h2>
        <p>Send your drawing — our engineers will recommend the right process and finish.</p>
      </div>
      <a href="rfq.php" class="btn btn-saffron">Request a Quote</a>
    </div>
  </section>

</main>

<?php 
// Include footer layout component
require_once __DIR__ . '/footer.php'; 
?>