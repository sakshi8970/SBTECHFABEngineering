<?php
/**
 * ==========================================================================
 * M-TECH ENGINEERING | HOME PAGE
 * ==========================================================================
 */
declare(strict_types=1);
require_once __DIR__ . '/db_connect.php';

$pageTitle = 'Home';

try {
    $services = mtech_get_services($pdo);
} catch (Throwable $e) {
    $services = [];
}
try {
    $products = mtech_get_products($pdo);
} catch (Throwable $e) {
    $products = [];
}

$fallbackServices = [
    ['title' => 'Laser Cutting', 'short_desc' => 'High-precision CNC fiber laser cutting up to 25mm mild steel.', 'slug' => 'laser-cutting'],
    ['title' => 'CNC Press Braking', 'short_desc' => 'Multi-axis CNC bending for complex enclosures and brackets.', 'slug' => 'cnc-press-braking'],
    ['title' => 'Robotic Welding', 'short_desc' => 'MIG/TIG and robotic welding cells for structural assemblies.', 'slug' => 'robotic-welding'],
    ['title' => 'Powder Coating', 'short_desc' => 'In-house electrostatic powder coating and finishing line.', 'slug' => 'powder-coating'],
];
$displayServices = !empty($services) ? $services : $fallbackServices;

$fallbackProducts = [
    [
        'title' => 'Armoured Equipment Enclosures', 
        'category' => 'defence', 
        'material' => 'MS / Armour Grade Steel', 
        'description' => 'Ruggedised enclosures fabricated to defence-grade tolerances.',
        'image_url' => 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=800&q=80'
    ],
    [
        'title' => 'Mounting Brackets & Racks', 
        'category' => 'defence', 
        'material' => 'Aluminium 6061', 
        'description' => 'Shock and vibration rated mounting hardware for vehicle systems.',
        'image_url' => 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=800&q=80'
    ],
    [
        'title' => 'Chassis Brackets', 
        'category' => 'automobile', 
        'material' => 'HR/CR Steel', 
        'description' => 'High-volume stamped and formed brackets for passenger vehicle chassis lines.',
        'image_url' => 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=800&q=80'
    ],
    [
        'title' => 'Exhaust & Heat Shield Panels', 
        'category' => 'automobile', 
        'material' => 'Aluminised Steel', 
        'description' => 'Formed heat shield components engineered for thermal performance.',
        'image_url' => 'https://images.unsplash.com/photo-1563720223185-11003d516935?auto=format&fit=crop&w=800&q=80'
    ],
    [
        'title' => 'Solar Mounting Structures', 
        'category' => 'solar', 
        'material' => 'Galvanised Steel', 
        'description' => 'Ground-mount and rooftop racking structures engineered for 25-year field life.',
        'image_url' => 'https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?auto=format&fit=crop&w=800&q=80'
    ],
    [
        'title' => 'Inverter & Junction Enclosures', 
        'category' => 'solar', 
        'material' => 'MS / Aluminium', 
        'description' => 'Weatherproof enclosures for inverters and junction assemblies.',
        'image_url' => 'https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?auto=format&fit=crop&w=800&q=80'
    ],
    [
        'title' => 'Industrial Storage Racking', 
        'category' => 'storage', 
        'material' => 'HR Steel', 
        'description' => 'Selective and heavy-duty pallet racking systems for warehouse environments.',
        'image_url' => 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=800&q=80'
    ],
    [
        'title' => 'Modular Storage Bins', 
        'category' => 'storage', 
        'material' => 'CR Steel', 
        'description' => 'Stackable, modular bins for component storage and material handling.',
        'image_url' => 'https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&w=800&q=80'
    ],
];
$displayProducts = !empty($products) ? $products : $fallbackProducts;

require_once __DIR__ . '/header.php';
?>

<main>

  <!-- ======================= HERO SLIDER ======================= -->
  <section class="hero" id="hero">
    <div class="hero-slides" id="heroSlides">
      <div class="hero-slide is-active" style="background-image:linear-gradient(115deg, rgba(0, 18, 36, 0.85), rgba(0, 36, 69, 0.75)), url('https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=1600&q=80'); background-size: cover; background-position: center;">
        <div class="container hero-slide-content">
          <p class="hero-eyebrow">40+ Years of Manufacturing Excellence</p>
          <h1>Engineered precision, fabricated to last.</h1>
          <p class="hero-sub">From laser-cut prototypes to defence-grade assemblies, M-Tech Engineering delivers tight-tolerance sheet metal fabrication for industries that cannot afford failure.</p>
          <div class="hero-actions">
            <a href="rfq.php" class="btn btn-saffron">Request a Quote</a>
            <a href="products.php" class="btn btn-outline-light">Browse Capabilities</a>
          </div>
        </div>
      </div>
      <div class="hero-slide" style="background-image:linear-gradient(115deg, rgba(0, 18, 36, 0.85), rgba(0, 36, 69, 0.75)), url('https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=1600&q=80'); background-size: cover; background-position: center;">
        <div class="container hero-slide-content">
          <p class="hero-eyebrow">Defence &middot; Automobile &middot; Solar &middot; Storage</p>
          <h1>One facility, four demanding industries.</h1>
          <p class="hero-sub">A single 11,000 sq. ft. facility houses laser cutting, CNC forming, robotic welding and finishing — built for industries where tolerances are non-negotiable.</p>
          <div class="hero-actions">
            <a href="rfq.php" class="btn btn-saffron">Request a Quote</a>
            <a href="about.php" class="btn btn-outline-light">About Our Facility</a>
          </div>
        </div>
      </div>
     <div class="hero-slide" style="background-image:linear-gradient(115deg, rgba(0, 18, 36, 0.85), rgba(0, 36, 69, 0.75)), url('https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?auto=format&fit=crop&w=1600&q=80'); background-size: cover; background-position: center;">
  <div class="container hero-slide-content">
    <p class="hero-eyebrow">In-House Quality Assurance</p>
    <h1>Every part measured. Every batch traceable.</h1>
    <p class="hero-sub">CMM inspection, material traceability and documented QA processes back every component that leaves our facility.</p>
    <div class="hero-actions">
      <a href="rfq.php" class="btn btn-saffron">Request a Quote</a>
      <a href="quality.php" class="btn btn-outline-light">Our Quality Process</a>
    </div>
  </div>
</div>
    </div>

    <div class="hero-nav">
      <button class="hero-dot is-active" data-slide="0" aria-label="Show slide 1"></button>
      <button class="hero-dot" data-slide="1" aria-label="Show slide 2"></button>
      <button class="hero-dot" data-slide="2" aria-label="Show slide 3"></button>
    </div>
  </section>

  <!-- ======================= ABOUT FACILITY STRIP ======================= -->
  <section class="about-strip">
    <div class="container about-strip-grid">
      <div class="about-strip-text">
        <p class="section-eyebrow">About Our Facility</p>
        <h2>Built for tolerance-critical manufacturing.</h2>
        <p>For over four decades, M-Tech Engineering has combined skilled fabrication with disciplined process control to serve OEMs across defence, automotive, renewable energy and industrial storage. Our integrated facility runs laser cutting, CNC press braking, robotic welding and powder coating under one roof, cutting handoffs and lead times without compromising tolerance.</p>
        <a href="about.php" class="text-link">Learn more about our facility &rarr;</a>
      </div>
      <div class="about-strip-media">
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcREmYNzz-IjUXkfZ527vWfG6_JdjgVvb7bQnacEn2ODTw&s=10" alt="M-Tech Engineering fabrication facility floor" loading="lazy">
      </div>
    </div>
  </section>

  <!-- ======================= LIVE COUNTERS ======================= -->
  <section class="counters" id="counters">
    <div class="container counters-grid">
      <div class="counter-item">
        <span class="counter-number" data-target="150">0</span><span class="counter-suffix">+</span>
        <p>Projects Delivered</p>
      </div>
      <div class="counter-item">
        <span class="counter-number" data-target="40">0</span><span class="counter-suffix">+</span>
        <p>Years in Manufacturing</p>
      </div>
      <div class="counter-item">
        <span class="counter-number" data-target="11000">0</span><span class="counter-suffix"> sq ft</span>
        <p>Manufacturing Facility</p>
      </div>
      <div class="counter-item">
        <span class="counter-number" data-target="98">0</span><span class="counter-suffix">%</span>
        <p>On-Time Delivery Rate</p>
      </div>
    </div>
  </section>

  <!-- ======================= SERVICES GRID ======================= -->
  <section class="services-section" id="services">
    <div class="container">
      <div class="section-heading">
        <p class="section-eyebrow">What We Do</p>
        <h2>Fabrication capabilities under one roof.</h2>
      </div>
      <div class="services-grid">
        <?php foreach ($displayServices as $service): ?>
          <article class="service-card" id="<?php echo htmlspecialchars($service['slug']); ?>">
            <h3><?php echo htmlspecialchars($service['title']); ?></h3>
            <p><?php echo htmlspecialchars($service['short_desc']); ?></p>
            <a href="services.php#<?php echo htmlspecialchars($service['slug']); ?>" class="text-link">Learn more &rarr;</a>
          </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ======================= FILTERABLE PRODUCTS GRID ======================= -->
  <section class="products-section" id="products">
    <div class="container">
      <div class="section-heading">
        <p class="section-eyebrow">What We Build</p>
        <h2>Products across four demanding industries.</h2>
      </div>

      <div class="product-filters" id="productFilters" role="group" aria-label="Filter products by industry">
        <button class="filter-btn is-active" data-filter="all">All</button>
        <button class="filter-btn" data-filter="defence">Defence</button>
        <button class="filter-btn" data-filter="automobile">Automobile</button>
        <button class="filter-btn" data-filter="solar">Solar</button>
        <button class="filter-btn" data-filter="storage">Storage</button>
      </div>

      <div class="products-grid" id="productsGrid">
        <?php foreach ($displayProducts as $index => $product): ?>
          <article class="product-card" data-category="<?php echo htmlspecialchars($product['category']); ?>">
            <div class="product-card-media">
              <img src="<?php echo htmlspecialchars(!empty($product['image_url']) ? $product['image_url'] : ($fallbackProducts[$index % count($fallbackProducts)]['image_url'] ?? 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=500')); ?>" 
                   alt="<?php echo htmlspecialchars($product['title']); ?>" 
                   onerror="this.onerror=null; this.src='<?php echo htmlspecialchars($fallbackProducts[$index % count($fallbackProducts)]['image_url'] ?? ''); ?>';" 
                   loading="lazy">
              <span class="product-tag"><?php echo htmlspecialchars(ucfirst($product['category'])); ?></span>
            </div>
            <div class="product-card-body">
              <h3><?php echo htmlspecialchars($product['title']); ?></h3>
              <?php if (!empty($product['material'])): ?>
                <p class="product-material"><?php echo htmlspecialchars($product['material']); ?></p>
              <?php endif; ?>
              <p><?php echo htmlspecialchars($product['description'] ?? ''); ?></p>
            </div>
          </article>
        <?php endforeach; ?>
      </div>

      <p class="products-empty" id="productsEmpty" hidden>No products match this filter yet — check back soon or contact us directly.</p>
    </div>
  </section>

  <!-- ======================= WORK PROCESS ======================= -->
  <section class="process-section" id="process">
    <div class="container">
      <div class="section-heading">
        <p class="section-eyebrow">How We Work</p>
        <h2>From drawing to delivery, in four steps.</h2>
      </div>
      <div class="process-grid">
        <div class="process-step">
          <span class="process-number">1</span>
          <h3>Share Your Drawing</h3>
          <p>Submit CAD files, PDFs or specifications through our RFQ form — our engineers review for manufacturability.</p>
        </div>
        <div class="process-step">
          <span class="process-number">2</span>
          <h3>Engineering Review</h3>
          <p>We assess tolerances, material and finish requirements, then return a detailed quotation and lead time.</p>
        </div>
        <div class="process-step">
          <span class="process-number">3</span>
          <h3>Fabrication &amp; QA</h3>
          <p>Parts move through cutting, forming, welding and finishing, with in-process inspection at every stage.</p>
        </div>
        <div class="process-step">
          <span class="process-number">4</span>
          <h3>Delivery</h3>
          <p>Finished components are packed, documented and dispatched on schedule, with full material traceability.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- ======================= CLIENT CAROUSEL ======================= -->
  <section class="clients-section" id="clients">
    <div class="container">
      <div class="section-heading">
        <p class="section-eyebrow">Trusted By</p>
        <h2>Manufacturers who rely on our tolerances.</h2>
      </div>
      <div class="clients-track" id="clientsTrack">
        <?php
        $clientNames = ['Vertex Defence Systems', 'Aravalli Auto Components', 'SunGrid Renewables', 'Northline Storage Solutions', 'Meridian Motors', 'CoreForm Industries'];
        foreach (array_merge($clientNames, $clientNames) as $name): ?>
          <div class="client-logo"><?php echo htmlspecialchars($name); ?></div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ======================= CTA BAND ======================= -->
  <section class="cta-band">
    <div class="container cta-band-inner">
      <div>
        <h2>Have a drawing ready?</h2>
        <p>Send it over and our engineering team will come back with a detailed quote within one business day.</p>
      </div>
      <a href="rfq.php" class="btn btn-saffron">Request a Quote</a>
    </div>
  </section>

</main>

<!-- Automatic Hero Slider Script -->
<script>
document.addEventListener('DOMContentLoaded', function () {
  const slides = document.querySelectorAll('.hero-slide');
  const dots = document.querySelectorAll('.hero-dot');
  let currentSlide = 0;
  const slideInterval = 2000; // Auto-slide every 2 seconds

  function showSlide(index) {
    slides.forEach((slide, i) => {
      slide.classList.toggle('is-active', i === index);
    });
    dots.forEach((dot, i) => {
      dot.classList.toggle('is-active', i === index);
    });
    currentSlide = index;
  }

  function nextSlide() {
    let next = (currentSlide + 1) % slides.length;
    showSlide(next);
  }

  let timer = setInterval(nextSlide, slideInterval);

  dots.forEach((dot, index) => {
    dot.addEventListener('click', () => {
      clearInterval(timer);
      showSlide(index);
      timer = setInterval(nextSlide, slideInterval);
    });
  });
});
</script>

<?php require_once __DIR__ . '/footer.php'; ?>