<?php
/**
 * ==========================================================================
 * M-TECH ENGINEERING | SECURE PDO DATABASE CONNECTION
 * ==========================================================================
 * Include this file wherever database access is required:
 *   require_once __DIR__ . '/db_connect.php';
 *   // then use the global $pdo (PDO) instance
 * ==========================================================================
 */

declare(strict_types=1);

// --------------------------------------------------------------------------
// 01. CONNECTION CONFIGURATION
// --------------------------------------------------------------------------
// In production, move these into environment variables rather than
// hard-coding credentials in source control.
$DB_HOST = getenv('MTECH_DB_HOST') ?: 'localhost';
$DB_PORT = getenv('MTECH_DB_PORT') ?: '3306';
$DB_NAME = getenv('MTECH_DB_NAME') ?: 'sakshu';
$DB_USER = getenv('MTECH_DB_USER') ?: 'root';
$DB_PASS = getenv('MTECH_DB_PASS') ?: '';

// --------------------------------------------------------------------------
// 02. PDO INSTANTIATION
// --------------------------------------------------------------------------
$dsn = sprintf(
    'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
    $DB_HOST,
    $DB_PORT,
    $DB_NAME
);

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false, // use real prepared statements
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4",
];

try {
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS, $options);
} catch (PDOException $e) {
    // Never leak credentials or raw exception details to the client.
    error_log('[M-Tech DB Connection Error] ' . $e->getMessage());
    http_response_code(500);
    die('A database connection error occurred. Please try again shortly.');
}

// --------------------------------------------------------------------------
// 03. HELPER: FETCH ACTIVE SERVICES
// --------------------------------------------------------------------------
function mtech_get_services(PDO $pdo): array
{
    $stmt = $pdo->query(
        'SELECT id, title, slug, short_desc, icon, image_url
         FROM services
         WHERE is_active = 1
         ORDER BY sort_order ASC, id ASC'
    );
    return $stmt->fetchAll();
}

// --------------------------------------------------------------------------
// 04. HELPER: FETCH ACTIVE PRODUCTS (OPTIONALLY FILTERED BY CATEGORY)
// --------------------------------------------------------------------------
function mtech_get_products(PDO $pdo, ?string $category = null): array
{
    if ($category !== null && $category !== 'all') {
        $stmt = $pdo->prepare(
            'SELECT id, category, title, slug, specs, description, image_url, material
             FROM products
             WHERE is_active = 1 AND category = :category
             ORDER BY sort_order ASC, id ASC'
        );
        $stmt->execute(['category' => $category]);
    } else {
        $stmt = $pdo->query(
            'SELECT id, category, title, slug, specs, description, image_url, material
             FROM products
             WHERE is_active = 1
             ORDER BY sort_order ASC, id ASC'
        );
    }
    return $stmt->fetchAll();
}
