<?php
/**
 * ==========================================================================
 * M-TECH ENGINEERING | RFQ / CONTACT FORM PROCESSOR
 * ==========================================================================
 * Handles POST submissions from the RFQ form on index.php:
 *  - Sanitises and validates every input field
 *  - Validates and stores an optional CAD/PDF drawing upload
 *  - Inserts the enquiry into the `inquiries` table via a prepared statement
 *  - Returns a JSON response for AJAX consumption (falls back to redirect)
 * ==========================================================================
 */

declare(strict_types=1);

require_once __DIR__ . '/db_connect.php';

header('Content-Type: application/json; charset=utf-8');

// --------------------------------------------------------------------------
// 01. METHOD GUARD
// --------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    exit;
}

// --------------------------------------------------------------------------
// 02. INPUT SANITIZATION & VALIDATION
// --------------------------------------------------------------------------
$errors = [];

$fullName = trim((string) filter_input(INPUT_POST, 'full_name', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
$email    = trim((string) filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL));
$phone    = trim((string) filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
$company  = trim((string) filter_input(INPUT_POST, 'company_name', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
$service  = trim((string) filter_input(INPUT_POST, 'service_type', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
$material = trim((string) filter_input(INPUT_POST, 'material_type', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
$quantity = trim((string) filter_input(INPUT_POST, 'quantity', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
$message  = trim((string) filter_input(INPUT_POST, 'message', FILTER_SANITIZE_FULL_SPECIAL_CHARS));

if ($fullName === '' || mb_strlen($fullName) > 120) {
    $errors[] = 'Please provide a valid full name.';
}
if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Please provide a valid email address.';
}
if ($phone === '' || !preg_match('/^[0-9+\-\s()]{7,20}$/', $phone)) {
    $errors[] = 'Please provide a valid phone number.';
}
if ($message !== '' && mb_strlen($message) > 4000) {
    $errors[] = 'Message is too long (4000 character maximum).';
}

// --------------------------------------------------------------------------
// 03. FILE UPLOAD HANDLING (CAD / PDF DRAWINGS)
// --------------------------------------------------------------------------
$storedFilename = null;
$uploadDir       = __DIR__ . '/uploads/drawings/';
$allowedExt      = ['pdf', 'dwg', 'dxf', 'png', 'jpg', 'jpeg'];
$maxBytes        = 10 * 1024 * 1024; // 10MB

if (isset($_FILES['drawing_file']) && $_FILES['drawing_file']['error'] !== UPLOAD_ERR_NO_FILE) {
    $file = $_FILES['drawing_file'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors[] = 'The file upload failed. Please try again.';
    } elseif ($file['size'] > $maxBytes) {
        $errors[] = 'The uploaded file exceeds the 10MB size limit.';
    } else {
        $originalName = basename($file['name']);
        $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

        if (!in_array($ext, $allowedExt, true)) {
            $errors[] = 'Unsupported file type. Allowed: PDF, DWG, DXF, PNG, JPG.';
        } elseif (!is_uploaded_file($file['tmp_name'])) {
            $errors[] = 'Invalid file upload.';
        } else {
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            // Sanitize filename: strip to safe characters, prefix with a
            // unique token to avoid collisions and directory traversal.
            $safeBase = preg_replace('/[^A-Za-z0-9_\-]/', '_', pathinfo($originalName, PATHINFO_FILENAME));
            $safeBase = substr($safeBase, 0, 80);
            $storedFilename = sprintf('%s_%s.%s', date('Ymd_His'), bin2hex(random_bytes(4)) . '_' . $safeBase, $ext);
            $destination = $uploadDir . $storedFilename;

            if (!move_uploaded_file($file['tmp_name'], $destination)) {
                $errors[] = 'Could not save the uploaded file. Please try again.';
                $storedFilename = null;
            }
        }
    }
}

// --------------------------------------------------------------------------
// 04. VALIDATION FAILURE RESPONSE
// --------------------------------------------------------------------------
if (!empty($errors)) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Please correct the errors below.', 'errors' => $errors]);
    exit;
}

// --------------------------------------------------------------------------
// 05. DATABASE INSERTION (PREPARED STATEMENT)
// --------------------------------------------------------------------------
try {
    $stmt = $pdo->prepare(
        'INSERT INTO inquiries
            (full_name, email, phone, company_name, service_type, material_type, quantity, message, drawing_file, ip_address, submitted_at)
         VALUES
            (:full_name, :email, :phone, :company_name, :service_type, :material_type, :quantity, :message, :drawing_file, :ip_address, NOW())'
    );

    $stmt->execute([
        'full_name'     => $fullName,
        'email'         => $email,
        'phone'         => $phone,
        'company_name'  => $company !== '' ? $company : null,
        'service_type'  => $service !== '' ? $service : null,
        'material_type' => $material !== '' ? $material : null,
        'quantity'      => $quantity !== '' ? $quantity : null,
        'message'       => $message !== '' ? $message : null,
        'drawing_file'  => $storedFilename,
        'ip_address'    => $_SERVER['REMOTE_ADDR'] ?? null,
    ]);

    echo json_encode([
        'success' => true,
        'message' => 'Thank you — your enquiry has been received. Our engineering team will respond within one business day.',
    ]);
} catch (PDOException $e) {
    error_log('[M-Tech RFQ Insert Error] ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'A server error occurred while saving your enquiry. Please try again.']);
}
