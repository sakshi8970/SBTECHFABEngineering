# M-Tech Engineering — Website Package

## Setup
1. Create the database and seed data:
   ```
   mysql -u root -p < schema.sql
   ```
2. Set connection credentials via environment variables (or edit the
   defaults directly in `db_connect.php`):
   ```
   MTECH_DB_HOST, MTECH_DB_PORT, MTECH_DB_NAME, MTECH_DB_USER, MTECH_DB_PASS
   ```
3. Ensure `uploads/drawings/` is writable by the web server user:
   ```
   chmod 755 uploads/drawings
   ```
4. Serve the folder with PHP (7.4+) and MySQL/MariaDB, e.g.:
   ```
   php -S localhost:8000
   ```
5. Open `index.php` in a browser.

## Files
| File | Purpose |
|---|---|
| `schema.sql` | Database DDL + seed data (services, products, inquiries, admin_users) |
| `db_connect.php` | Secure PDO connection + data-fetch helpers |
| `header.php` | Top bar, sticky navbar, hover/accordion dropdowns |
| `footer.php` | Footer, floating WhatsApp button, scroll-to-top, script include |
| `index.php` | Home page: hero slider, about strip, live counters, services, filterable products, process steps, client marquee |
| `process_rfq.php` | RFQ form handler: validation, file upload, DB insert |
| `style.css` | Full design system and layout styles |
| `main.js` | Navigation, counters, filters, hero slider, RFQ form logic |

## Notes
- Add real photography to `assets/images/` (hero-fabrication.jpg,
  hero-welding.jpg, hero-quality.jpg, facility-overview.jpg,
  product-placeholder.jpg, favicon.png) — these are referenced but not
  included in this package.
- `about.php`, `services.php`, `products.php`, `quality.php`,
  `contact.php`, `rfq.php`, `privacy.php` and `terms.php` are linked from
  the nav/footer as the natural next pages; `index.php` is fully built as
  the flagship page per the brief. Reuse `header.php`/`footer.php` and the
  section styles (04–06 in `style.css`) already provided to build them out.
