<?php
/**
 * ==========================================================================
 * M-TECH ENGINEERING | PRODUCTS PAGE
 * ==========================================================================
 * Supports an optional ?category= query param (defence/automobile/solar/
 * storage) to pre-select a filter on load; client-side JS (main.js) then
 * handles instant re-filtering without a page reload.
 */

declare(strict_types=1);
require_once __DIR__ . '/db_connect.php';

// Set current page title
$pageTitle = 'Products';

// Category filter validation logic
$validCategories = ['defence', 'automobile', 'solar', 'storage'];
$activeCategory = $_GET['category'] ?? 'all';
if (!in_array($activeCategory, $validCategories, true)) {
    $activeCategory = 'all';
}

// Fetch products from the database with error handling
try {
    $products = mtech_get_products($pdo);
} catch (Throwable $e) {
    $products = [];
}

/**
 * Fallback products dataset used when the database returns empty results
 */
$fallbackProducts = [
    ['title' => 'Armoured Equipment Enclosures', 'category' => 'defence', 'material' => 'MS / Armour Grade Steel', 'specs' => 'Thickness: 3-12mm | Finish: CARC coating | Standard: MIL-SPEC', 'description' => 'Ruggedised enclosures fabricated to defence-grade tolerances for field electronics and equipment protection.'],
    ['title' => 'Mounting Brackets & Racks', 'category' => 'defence', 'material' => 'Aluminium 6061', 'specs' => 'Thickness: 2-8mm | Finish: Powder coated | Standard: MIL-STD-810', 'description' => 'Shock and vibration rated mounting hardware for vehicle-mounted and shelter-based systems.'],
    ['title' => 'Chassis Brackets', 'category' => 'automobile', 'material' => 'HR/CR Steel', 'specs' => 'Thickness: 1.5-6mm | Finish: E-coat | Tolerance: ±0.1mm', 'description' => 'High-volume stamped and formed brackets for passenger and commercial vehicle chassis lines.'],
    ['title' => 'Exhaust & Heat Shield Panels', 'category' => 'automobile', 'material' => 'Aluminised Steel', 'specs' => 'Thickness: 0.8-2mm | Finish: Aluminised coating', 'description' => 'Formed heat shield components engineered for thermal performance and long service life.'],
    ['title' => 'Solar Mounting Structures', 'category' => 'solar', 'material' => 'Galvanised Steel', 'specs' => 'Thickness: 2-5mm | Finish: Hot-dip galvanised | Wind rating: up to 180 km/h', 'description' => 'Ground-mount and rooftop racking structures engineered for 25-year field life in varied terrain.'],
    ['title' => 'Inverter & Junction Enclosures', 'category' => 'solar', 'material' => 'MS / Aluminium', 'specs' => 'Thickness: 1.5-3mm | IP Rating: IP65 | Finish: Powder coated', 'description' => 'Weatherproof enclosures for inverters, combiner boxes and junction assemblies.'],
    ['title' => 'Industrial Storage Racking', 'category' => 'storage', 'material' => 'HR Steel', 'specs' => 'Load capacity: up to 5T/bay | Finish: Powder coated', 'description' => 'Selective and heavy-duty pallet racking systems engineered for warehouse and cold-storage environments.'],
    ['title' => 'Modular Storage Bins', 'category' => 'storage', 'material' => 'CR Steel', 'specs' => 'Capacity: 20-500L | Finish: Powder coated', 'description' => 'Stackable, modular bins for component storage and material handling in production environments.'],
];

/**
 * Image URL mapping by numeric index position to eliminate broken image paths
 */
$productImagesByIndex = [
    0 => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSyR38y2GNe-VvYRXCxMZFXR2JH7xP28UufYowWfeJrieX4WMVu2ACQPFVT&s=10', // 1. Defence Enclosures
    1 => 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=800&q=80', // 2. Mounting Brackets
    2 => 'https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?auto=format&fit=crop&w=800&q=80', // 3. Chassis Brackets
    3 => 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=800&q=80', // 4. Heat Shield Panels
    4 => 'https://5.imimg.com/data5/SELLER/Default/2025/2/491114350/AE/ZK/RS/9231311/ground-mounted-solar-structure-500x500.jpg', // 5. Solar Mounting
    5 => 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=800&q=80', // 6. Inverter Enclosures
    6 => 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=800&q=80', // 7. Storage Racking
    7 => 'https://images.unsplash.com/photo-1553413077-190dd305871c?auto=format&fit=crop&w=800&q=80'  // 8. Modular Storage Bins
];

// Determine the final active products dataset
$displayProducts = !empty($products) ? $products : $fallbackProducts;

// Include header layout component
require_once __DIR__ . '/header.php';
?>

<main>

  <!-- ==========================================================================
       01. PAGE HERO SECTION
       ========================================================================== -->
  <section class="page-hero">
    <div class="container">
      <p class="hero-eyebrow">Our Products</p>
      <h1>Fabricated products across four industries.</h1>
      <p>Every product below is built to customer drawings and specifications — the categories reflect the industries we serve most, not a fixed catalogue.</p>
    </div>
  </section>

  <!-- ==========================================================================
       02. FILTERABLE PRODUCTS GRID SECTION
       ========================================================================== -->
  <section class="products-section products-page-header">
    <div class="container">

      <!-- Category Filter Navigation Buttons -->
      <div class="product-filters" id="productFilters" role="group" aria-label="Filter products by industry">
        <button class="filter-btn<?php echo $activeCategory === 'all' ? ' is-active' : ''; ?>" data-filter="all">All</button>
        <button class="filter-btn<?php echo $activeCategory === 'defence' ? ' is-active' : ''; ?>" data-filter="defence">Defence</button>
        <button class="filter-btn<?php echo $activeCategory === 'automobile' ? ' is-active' : ''; ?>" data-filter="automobile">Automobile</button>
        <button class="filter-btn<?php echo $activeCategory === 'solar' ? ' is-active' : ''; ?>" data-filter="solar">Solar</button>
        <button class="filter-btn<?php echo $activeCategory === 'storage' ? ' is-active' : ''; ?>" data-filter="storage">Storage</button>
      </div>

      <!-- Products Grid Display -->
      <div class="products-grid" id="productsGrid">
        <?php foreach ($displayProducts as $i => $product): ?>
          <?php
            // Check if item should be hidden initially based on active URL parameter
            $isHiddenOnLoad = $activeCategory !== 'all' && $product['category'] !== $activeCategory;
            
            // Priority selection: Database URL -> Array Index Fallback -> Default Placeholder
            $imageUrl = $product['image_url'] ?? $productImagesByIndex[$i] ?? 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=800&q=80';
          ?>
          <article class="product-card" data-category="<?php echo htmlspecialchars($product['category']); ?>" <?php echo $isHiddenOnLoad ? 'style="display:none;"' : ''; ?>>
            
            <!-- Product Media Container -->
            <div class="product-card-media">
              <img src="<?php echo htmlspecialchars($imageUrl); ?>" 
                   alt="<?php echo htmlspecialchars($product['title']); ?>" 
                   loading="lazy">
              <span class="product-tag"><?php echo htmlspecialchars(ucfirst($product['category'])); ?></span>
            </div>

            <!-- Product Description Container -->
            <div class="product-card-body">
              <h3><?php echo htmlspecialchars($product['title']); ?></h3>
              <?php if (!empty($product['material'])): ?>
                <p class="product-material"><?php echo htmlspecialchars($product['material']); ?></p>
              <?php endif; ?>
              <p><?php echo htmlspecialchars($product['description'] ?? ''); ?></p>
              <?php if (!empty($product['specs'])): ?>
                <p style="font-size:.85rem;color:var(--muted);"><?php echo htmlspecialchars($product['specs']); ?></p>
              <?php endif; ?>
            </div>

          </article>
        <?php endforeach; ?>
      </div>

      <!-- Empty State Message when no filter matches -->
      <p class="products-empty" id="productsEmpty" hidden>No products match this filter yet — check back soon or contact us directly.</p>
    </div>
  </section>

  <!-- ==========================================================================
       03. CALL TO ACTION (CTA) BAND
       ========================================================================== -->
  <section class="cta-band">
    <div class="container cta-band-inner">
      <div>
        <h2>Need a product that isn't listed?</h2>
        <p>Most of what we build starts as a custom drawing. Send yours over for a quote.</p>
      </div>
      <a href="rfq.php" class="btn btn-saffron">Request a Quote</a>
    </div>
  </section>

</main>

<?php 
// Include footer layout component
require_once __DIR__ . '/footer.php'; 
?>