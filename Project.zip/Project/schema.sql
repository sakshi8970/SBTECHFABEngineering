-- ==========================================================================
-- M-TECH ENGINEERING | DATABASE SCHEMA
-- Precision Sheet Metal Fabrication & Advanced Manufacturing Solutions
-- ==========================================================================
-- Import this file into MySQL 5.7+/MariaDB 10.3+ using:
--   mysql -u root -p mtech_engineering < schema.sql
-- ==========================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS `sakshu`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `sakshu`;

-- --------------------------------------------------------------------------
-- Table: services
-- Core capability listings (Laser Cutting, CNC Bending, Welding, etc.)
-- --------------------------------------------------------------------------
DROP TABLE IF EXISTS `services`;
CREATE TABLE `services` (
  `id`          INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `title`       VARCHAR(150)    NOT NULL,
  `slug`        VARCHAR(160)    NOT NULL,
  `short_desc`  VARCHAR(300)    NOT NULL,
  `full_desc`   TEXT            NULL,
  `icon`        VARCHAR(60)     NULL COMMENT 'Icon key/class used in the UI',
  `image_url`   VARCHAR(255)    NULL,
  `sort_order`  SMALLINT        NOT NULL DEFAULT 0,
  `is_active`   TINYINT(1)      NOT NULL DEFAULT 1,
  `created_at`  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_services_slug` (`slug`),
  KEY `idx_services_active_sort` (`is_active`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------------
-- Table: products
-- Fabricated product catalogue, filterable by industry category
-- --------------------------------------------------------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id`          INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `category`    ENUM('defence','automobile','solar','storage','general') NOT NULL DEFAULT 'general',
  `title`       VARCHAR(150)    NOT NULL,
  `slug`        VARCHAR(160)    NOT NULL,
  `specs`       TEXT            NULL COMMENT 'Key specifications, one per line or JSON',
  `description` TEXT            NULL,
  `image_url`   VARCHAR(255)    NULL,
  `material`    VARCHAR(100)    NULL COMMENT 'e.g. MS, SS304, Aluminium',
  `sort_order`  SMALLINT        NOT NULL DEFAULT 0,
  `is_active`   TINYINT(1)      NOT NULL DEFAULT 1,
  `created_at`  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_products_slug` (`slug`),
  KEY `idx_products_category` (`category`),
  KEY `idx_products_active_sort` (`is_active`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------------
-- Table: inquiries
-- Request-for-Quotation (RFQ) submissions from the contact/RFQ form
-- --------------------------------------------------------------------------
DROP TABLE IF EXISTS `inquiries`;
CREATE TABLE `inquiries` (
  `id`             INT UNSIGNED   NOT NULL AUTO_INCREMENT,
  `full_name`      VARCHAR(120)   NOT NULL,
  `email`          VARCHAR(160)   NOT NULL,
  `phone`          VARCHAR(30)    NOT NULL,
  `company_name`   VARCHAR(160)   NULL,
  `service_type`   VARCHAR(100)   NULL,
  `material_type`  VARCHAR(100)   NULL,
  `quantity`       VARCHAR(50)    NULL,
  `message`        TEXT           NULL,
  `drawing_file`   VARCHAR(255)   NULL COMMENT 'Stored filename under uploads/drawings/',
  `status`         ENUM('new','reviewed','quoted','closed') NOT NULL DEFAULT 'new',
  `ip_address`     VARCHAR(45)    NULL,
  `submitted_at`   TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_inquiries_status` (`status`),
  KEY `idx_inquiries_submitted` (`submitted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------------
-- Table: admin_users
-- Backend administrator accounts
-- --------------------------------------------------------------------------
DROP TABLE IF EXISTS `admin_users`;
CREATE TABLE `admin_users` (
  `id`             INT UNSIGNED   NOT NULL AUTO_INCREMENT,
  `username`       VARCHAR(60)    NOT NULL,
  `password_hash`  VARCHAR(255)   NOT NULL COMMENT 'Generated via PHP password_hash()',
  `full_name`      VARCHAR(120)   NULL,
  `email`          VARCHAR(160)   NULL,
  `last_login_at`  TIMESTAMP      NULL DEFAULT NULL,
  `created_at`     TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_admin_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- --------------------------------------------------------------------------
-- Seed data: services
-- --------------------------------------------------------------------------
INSERT INTO `services` (`title`, `slug`, `short_desc`, `full_desc`, `icon`, `sort_order`) VALUES
('Laser Cutting', 'laser-cutting', 'High-precision CNC fiber laser cutting up to 25mm mild steel.', 'Our fiber laser cutting cells hold tight tolerances across mild steel, stainless steel and aluminium, enabling fast-turnaround prototypes and high-volume production runs alike.', 'laser', 1),
('CNC Press Braking', 'cnc-press-braking', 'Multi-axis CNC bending for complex enclosures and brackets.', 'CNC press brakes with programmable back-gauges deliver repeatable bend angles across long production runs, supporting everything from thin-gauge panels to structural brackets.', 'bend', 2),
('Robotic Welding', 'robotic-welding', 'MIG/TIG and robotic welding cells for structural assemblies.', 'Certified welders and robotic welding cells combine to deliver consistent, code-compliant joints on both small components and large fabricated structures.', 'weld', 3),
('Powder Coating', 'powder-coating', 'In-house electrostatic powder coating and finishing line.', 'A dedicated pre-treatment and powder coating line provides corrosion-resistant, durable finishes in a wide range of RAL colours.', 'coating', 4),
('Sheet Metal Fabrication', 'sheet-metal-fabrication', 'End-to-end fabrication from design to finished assembly.', 'From DFM review through cutting, forming, welding and finishing, we manage the full fabrication lifecycle under one roof.', 'fabrication', 5),
('Tool & Die Manufacturing', 'tool-die-manufacturing', 'Precision tooling for high-volume stamping operations.', 'In-house tool room capabilities support progressive and compound die design and build for demanding stamping applications.', 'tooling', 6);

-- --------------------------------------------------------------------------
-- Seed data: products
-- --------------------------------------------------------------------------
INSERT INTO `products` (`category`, `title`, `slug`, `specs`, `description`, `material`, `sort_order`) VALUES
('defence', 'Armoured Equipment Enclosures', 'armoured-equipment-enclosures', 'Thickness: 3-12mm | Finish: CARC coating | Standard: MIL-SPEC', 'Ruggedised enclosures fabricated to defence-grade tolerances for field electronics and equipment protection.', 'MS / Armour Grade Steel', 1),
('defence', 'Mounting Brackets & Racks', 'defence-mounting-brackets', 'Thickness: 2-8mm | Finish: Powder coated | Standard: MIL-STD-810', 'Shock and vibration rated mounting hardware for vehicle-mounted and shelter-based systems.', 'Aluminium 6061', 2),
('automobile', 'Chassis Brackets', 'chassis-brackets', 'Thickness: 1.5-6mm | Finish: E-coat | Tolerance: ±0.1mm', 'High-volume stamped and formed brackets for passenger and commercial vehicle chassis lines.', 'HR/CR Steel', 3),
('automobile', 'Exhaust & Heat Shield Panels', 'exhaust-heat-shield-panels', 'Thickness: 0.8-2mm | Finish: Aluminised coating', 'Formed heat shield components engineered for thermal performance and long service life.', 'Aluminised Steel', 4),
('solar', 'Solar Mounting Structures', 'solar-mounting-structures', 'Thickness: 2-5mm | Finish: Hot-dip galvanised | Wind rating: up to 180 km/h', 'Ground-mount and rooftop racking structures engineered for 25-year field life in varied terrain.', 'Galvanised Steel', 5),
('solar', 'Inverter & Junction Enclosures', 'inverter-junction-enclosures', 'Thickness: 1.5-3mm | IP Rating: IP65 | Finish: Powder coated', 'Weatherproof enclosures for inverters, combiner boxes and junction assemblies.', 'MS / Aluminium', 6),
('storage', 'Industrial Storage Racking', 'industrial-storage-racking', 'Load capacity: up to 5T/bay | Finish: Powder coated', 'Selective and heavy-duty pallet racking systems engineered for warehouse and cold-storage environments.', 'HR Steel', 7),
('storage', 'Modular Storage Bins', 'modular-storage-bins', 'Capacity: 20-500L | Finish: Powder coated', 'Stackable, modular bins for component storage and material handling in production environments.', 'CR Steel', 8);
