<?php
/**
 * ==========================================================================
 * M-TECH ENGINEERING | CONTACT PAGE
 * ==========================================================================
 */
declare(strict_types=1);
require_once __DIR__ . '/db_connect.php';

$pageTitle = 'Contact Us';
require_once __DIR__ . '/header.php';
?>

<main>

  <!-- ======================= PAGE HERO ======================= -->
  <section class="page-hero">
    <div class="container">
      <p class="hero-eyebrow">Contact Us</p>
      <h1>Talk to our engineering team.</h1>
      <p>Questions about a process, a material or a project timeline? Reach out directly, or send drawings through our <a href="rfq.php" style="color:#fff;text-decoration:underline;">RFQ form</a> for a formal quote.</p>
    </div>
  </section>

  <!-- ======================= CONTACT DETAILS + FORM ======================= -->
  <section class="rfq-section">
    <div class="container rfq-layout">

      <!-- Short enquiry form -->
      <div class="rfq-card">
        <h2>Send Us a Message</h2>
        <p>For general questions. For formal quotations with drawings, please use the <a href="rfq.php" class="text-link">RFQ form</a> instead.</p>

        <form id="rfqForm" novalidate>
          <div class="form-row">
            <div class="form-group">
              <label for="full_name">Full Name <span class="required">*</span></label>
              <input type="text" id="full_name" name="full_name" required>
            </div>
            <div class="form-group">
              <label for="email">Email Address <span class="required">*</span></label>
              <input type="email" id="email" name="email" required>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label for="phone">Phone Number <span class="required">*</span></label>
              <input type="tel" id="phone" name="phone" required>
            </div>
            <div class="form-group">
              <label for="company_name">Company Name</label>
              <input type="text" id="company_name" name="company_name">
            </div>
          </div>

          <div class="form-group">
            <label for="message">Message</label>
            <textarea id="message" name="message" placeholder="How can we help?"></textarea>
          </div>

          <!-- Hidden file input kept for schema compatibility with process_rfq.php; not shown on this shorter form. -->
          <input type="file" id="drawingFile" name="drawing_file" hidden>

          <button type="submit" class="btn btn-saffron form-submit" id="rfqSubmitBtn">Send Message</button>
          <div class="form-status" id="formStatus"></div>
        </form>
      </div>

      <!-- Contact details + map -->
      <div>
        <div class="rfq-info-card">
          <h3>Visit Our Facility</h3>
          <p>We welcome scheduled visits and customer audits.</p>
          <ul class="rfq-info-list">
            <li>
              <a href="https://maps.google.com/?q=Plot+14,+Industrial+Estate,+Pune,+Maharashtra,+India" target="_blank" rel="noopener" style="color: inherit; text-decoration: none;">
                <span aria-hidden="true">&#9737;</span> Plot 14, Industrial Estate, Pune, Maharashtra, India
              </a>
            </li>
            <li>
              <a href="tel:+911234567890" style="color: inherit; text-decoration: none;">
                <span aria-hidden="true">&#9742;</span> +91 12345 67890
              </a>
            </li>
            <li>
              <a href="mailto:info@mtechengineering.com" style="color: inherit; text-decoration: none;">
                <span aria-hidden="true">&#9993;</span> info@mtechengineering.com
              </a>
            </li>
            <li><span aria-hidden="true">&#128337;</span> Mon&ndash;Sat, 9:00&ndash;18:00 IST</li>
          </ul>
        </div>

        <div style="border-radius: var(--radius-md); overflow:hidden; border:1px solid var(--line);">
          <iframe
            title="M-Tech Engineering facility location"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4247.857394025081!2d73.85141697519012!3d18.45492128262597!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2eac6040cb269%3A0xac653591baaaa13e!2sSarhad%20College%20of%20Arts%2CCommerce%20and%20Science!5e1!3m2!1sen!2sin!4v1790091416759!5m2!1sen!2sin"
            width="100%" height="320" style="border:0; display:block;"
            loading="lazy" referrerpolicy="no-referrer-when-downgrade">
          </iframe>
        </div>
      </div>

    </div>
  </section>

</main>

<?php require_once __DIR__ . '/footer.php'; ?>