<?php
/**
 * ==========================================================================
 * M-TECH ENGINEERING | QUALITY & INFRASTRUCTURE PAGE
 * ==========================================================================
 */
declare(strict_types=1);
require_once __DIR__ . '/db_connect.php';

$pageTitle = 'Quality & Infrastructure';
require_once __DIR__ . '/header.php';
?>

<main>

  <!-- ======================= PAGE HERO ======================= -->
  <section class="page-hero">
    <div class="container">
      <p class="hero-eyebrow">Quality &amp; Infrastructure</p>
      <h1>Every part measured. Every batch traceable.</h1>
      <p>Our quality process runs alongside production, not after it — with documented checks at every stage from incoming material to final dispatch.</p>
    </div>
  </section>

  <!-- ======================= QA PROCESS STEPS ======================= -->
  <section class="process-section">
    <div class="container">
      <div class="section-heading">
        <p class="section-eyebrow">Our QA Process</p>
        <h2>Inspection built into every stage.</h2>
      </div>
      <div class="process-grid">
        <div class="process-step">
          <span class="process-number">1</span>
          <h3>Incoming Material Check</h3>
          <p>Raw material is verified against mill certificates before it enters production, with full lot traceability.</p>
        </div>
        <div class="process-step">
          <span class="process-number">2</span>
          <h3>In-Process Inspection</h3>
          <p>First-article and periodic in-process checks catch tolerance drift early, before a full batch is affected.</p>
        </div>
        <div class="process-step">
          <span class="process-number">3</span>
          <h3>CMM &amp; Dimensional Verification</h3>
          <p>Critical dimensions are verified on our coordinate measuring machine against the original drawing.</p>
        </div>
        <div class="process-step">
          <span class="process-number">4</span>
          <h3>Final Inspection &amp; Documentation</h3>
          <p>Every outgoing batch is packed with inspection reports and material certificates for full traceability.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- ======================= INFRASTRUCTURE / EQUIPMENT ======================= -->
  <section class="services-section" style="background: var(--wash);">
    <div class="container">
      <div class="section-heading">
        <p class="section-eyebrow">Our Infrastructure</p>
        <h2>11,000 sq. ft. of integrated manufacturing.</h2>
      </div>
      <div class="services-grid">
        <article class="service-card">
          <h3>Fiber Laser Cutting</h3>
          <p>CNC fiber laser cutting cells for mild steel, stainless steel and aluminium up to 25mm thickness.</p>
        </article>
        <article class="service-card">
          <h3>CNC Press Brakes</h3>
          <p>Multi-axis CNC press brakes with programmable back-gauges for repeatable, complex bends.</p>
        </article>
        <article class="service-card">
          <h3>Robotic &amp; Manual Welding</h3>
          <p>Robotic MIG welding cells alongside certified manual MIG/TIG welding stations.</p>
        </article>
        <article class="service-card">
          <h3>Powder Coating Line</h3>
          <p>Seven-tank pre-treatment process feeding an electrostatic powder coating and cure line.</p>
        </article>
        <article class="service-card">
          <h3>CMM Inspection</h3>
          <p>Coordinate measuring machine for high-precision dimensional verification against drawings.</p>
        </article>
        <article class="service-card">
          <h3>In-House Tool Room</h3>
          <p>Design and build of progressive and compound dies for high-volume stamping operations.</p>
        </article>
      </div>
    </div>
  </section>

  <!-- ======================= CERTIFICATIONS ======================= -->
  <section class="about-values">
    <div class="container about-values">
      <div class="value-card">
        <h3>ISO 9001:2015</h3>
        <p>Quality management system certification covering our full manufacturing process.</p>
      </div>
      <div class="value-card">
        <h3>Material Traceability</h3>
        <p>Every batch is traceable back to its raw material heat/lot number and mill certificate.</p>
      </div>
      <div class="value-card">
        <h3>Defence Supplier Qualification</h3>
        <p>Qualified to supply components meeting MIL-SPEC and MIL-STD documentation requirements.</p>
      </div>
    </div>
  </section>

  <!-- ======================= CTA BAND ======================= -->
  <section class="cta-band">
    <div class="container cta-band-inner">
      <div>
        <h2>Want to audit our facility?</h2>
        <p>We welcome customer audits and quality reviews — get in touch to schedule a visit.</p>
      </div>
      <a href="contact.php" class="btn btn-saffron">Contact Us</a>
    </div>
  </section>

</main>

<?php require_once __DIR__ . '/footer.php'; ?>
