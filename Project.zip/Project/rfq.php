<?php
/**
 * ==========================================================================
 * M-TECH ENGINEERING | REQUEST FOR QUOTATION (RFQ) PAGE
 * ==========================================================================
 */
declare(strict_types=1);
require_once __DIR__ . '/db_connect.php';

$pageTitle = 'Request a Quote';

try {
    $services = mtech_get_services($pdo);
} catch (Throwable $e) {
    $services = [];
}
$serviceOptions = !empty($services) ? array_column($services, 'title') : [
    'Laser Cutting', 'CNC Press Braking', 'Robotic Welding', 'Powder Coating',
    'Sheet Metal Fabrication', 'Tool & Die Manufacturing', 'Not sure / Other',
];

require_once __DIR__ . '/header.php';
?>

<main>

  <!-- ======================= PAGE HERO ======================= -->
  <section class="page-hero">
    <div class="container">
      <p class="hero-eyebrow">Request a Quote</p>
      <h1>Send your drawing, get a real quote.</h1>
      <p>Upload your CAD file, PDF or specification and our engineering team will respond within one business day with a detailed quotation and lead time.</p>
    </div>
  </section>

  <!-- ======================= RFQ FORM ======================= -->
  <section class="rfq-section">
    <div class="container rfq-layout">

      <div class="rfq-card">
        <h2>Project Details</h2>
        <p>Fields marked <span class="required">*</span> are required.</p>

        <form id="rfqForm" novalidate enctype="multipart/form-data">
          <div class="form-row">
            <div class="form-group">
              <label for="full_name">Full Name <span class="required">*</span></label>
              <input type="text" id="full_name" name="full_name" required>
            </div>
            <div class="form-group">
              <label for="company_name">Company Name</label>
              <input type="text" id="company_name" name="company_name">
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label for="email">Email Address <span class="required">*</span></label>
              <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
              <label for="phone">Phone Number <span class="required">*</span></label>
              <input type="tel" id="phone" name="phone" required>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label for="service_type">Service Required</label>
              <select id="service_type" name="service_type">
                <option value="">Select a service&hellip;</option>
                <?php foreach ($serviceOptions as $option): ?>
                  <option value="<?php echo htmlspecialchars($option); ?>"><?php echo htmlspecialchars($option); ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label for="material_type">Material Type</label>
              <input type="text" id="material_type" name="material_type" placeholder="e.g. Mild Steel, SS304, Aluminium">
            </div>
          </div>

          <div class="form-group">
            <label for="quantity">Estimated Quantity</label>
            <input type="text" id="quantity" name="quantity" placeholder="e.g. 500 units / month, one-off prototype">
          </div>

          <div class="form-group">
            <label for="message">Project Details</label>
            <textarea id="message" name="message" placeholder="Tolerances, finish requirements, timeline, or anything else we should know."></textarea>
          </div>

          <div class="form-group">
            <label for="drawingFile">CAD Drawing / Specification</label>
            <div class="file-drop" id="fileDrop">
              <p style="margin-bottom:4px;">Drag &amp; drop a file here, or click to browse</p>
              <p style="font-size:.8rem; margin:0;">PDF, DWG, DXF, PNG or JPG &middot; 10MB max</p>
              <p class="file-drop-filename" id="fileDropFilename"></p>
              <input type="file" id="drawingFile" name="drawing_file" accept=".pdf,.dwg,.dxf,.png,.jpg,.jpeg">
            </div>
          </div>

          <button type="submit" class="btn btn-saffron form-submit" id="rfqSubmitBtn">Submit Request</button>
          <div class="form-status" id="formStatus"></div>
        </form>
      </div>

      <div>
        <div class="rfq-info-card">
          <h3>What Happens Next</h3>
          <ul class="rfq-info-list">
            <li><span aria-hidden="true">1.</span> Our engineers review your drawing for manufacturability.</li>
            <li><span aria-hidden="true">2.</span> You receive a detailed quote and lead time within one business day.</li>
            <li><span aria-hidden="true">3.</span> On approval, we schedule production and keep you updated.</li>
          </ul>
        </div>

        <div class="rfq-info-card" style="background: var(--surface); border: 1px solid var(--line); color: var(--ink);">
          <h3 style="color: var(--navy-deep);">Prefer to talk it through?</h3>
          <p style="color: var(--muted);">Call our engineering team directly for complex or urgent requirements.</p>
          <ul class="rfq-info-list">
            <li style="color: var(--muted);"><span aria-hidden="true">&#9742;</span> +91 12345 67890</li>
            <li style="color: var(--muted);"><span aria-hidden="true">&#9993;</span> info@mtechengineering.com</li>
          </ul>
        </div>
      </div>

    </div>
  </section>

</main>

<?php require_once __DIR__ . '/footer.php'; ?>
