<?php
/**
 * ==========================================================================
 * M-TECH ENGINEERING | PRIVACY POLICY PAGE
 * ==========================================================================
 */
declare(strict_types=1);
require_once __DIR__ . '/db_connect.php';

$pageTitle = 'Privacy Policy';
require_once __DIR__ . '/header.php';
?>

<main>

  <!-- ======================= PAGE HERO ======================= -->
  <section class="page-hero">
    <div class="container">
      <p class="hero-eyebrow">Legal</p>
      <h1>Privacy Policy</h1>
      <p>Last updated: <?php echo date('F Y'); ?></p>
    </div>
  </section>

  <!-- ======================= POLICY CONTENT ======================= -->
  <section class="container" style="padding: 20px 0 96px; max-width: 780px;">

    <h2>Information We Collect</h2>
    <p>When you submit an enquiry or request for quotation (RFQ) through this website, we collect the information you provide directly: your name, email address, phone number, company name, and any project details, specifications or files you choose to upload.</p>

    <h2>How We Use Your Information</h2>
    <p>Information submitted through our contact and RFQ forms is used solely to respond to your enquiry, prepare quotations, and communicate about your project. We do not sell or rent your personal information to third parties.</p>

    <h2>File Uploads</h2>
    <p>Drawings and specification files uploaded through our RFQ form are stored securely and used only for the purpose of preparing your quotation. Files are retained for as long as reasonably necessary to support your enquiry or an active project.</p>

    <h2>Data Retention</h2>
    <p>Enquiry records are retained for as long as needed to respond to your request and maintain reasonable business records, after which they may be archived or deleted.</p>

    <h2>Your Rights</h2>
    <p>You may request a copy of the information we hold about you, or request that it be corrected or deleted, by contacting us at the details below.</p>

    <h2>Contact Us</h2>
    <p>If you have questions about this privacy policy, please contact us at <a href="mailto:info@mtechengineering.com" class="text-link">info@mtechengineering.com</a> or through our <a href="contact.php" class="text-link">contact page</a>.</p>

  </section>

</main>

<?php require_once __DIR__ . '/footer.php'; ?>
