<?php
/**
 * ==========================================================================
 * M-TECH ENGINEERING | TERMS OF SERVICE PAGE
 * ==========================================================================
 */
declare(strict_types=1);
require_once __DIR__ . '/db_connect.php';

$pageTitle = 'Terms of Service';
require_once __DIR__ . '/header.php';
?>

<main>

  <!-- ======================= PAGE HERO ======================= -->
  <section class="page-hero">
    <div class="container">
      <p class="hero-eyebrow">Legal</p>
      <h1>Terms of Service</h1>
      <p>Last updated: <?php echo date('F Y'); ?></p>
    </div>
  </section>

  <!-- ======================= TERMS CONTENT ======================= -->
  <section class="container" style="padding: 20px 0 96px; max-width: 780px;">

    <h2>Use of This Website</h2>
    <p>This website is provided to share information about M-Tech Engineering's manufacturing capabilities and to allow prospective customers to request quotations. By using this site, you agree to provide accurate information through our contact and RFQ forms.</p>

    <h2>Quotations</h2>
    <p>Quotations provided in response to an RFQ submission are estimates based on the information and files supplied, and are subject to confirmation after full engineering review. Final pricing, lead times and terms will be confirmed in a formal quotation document.</p>

    <h2>Intellectual Property</h2>
    <p>Drawings and specifications submitted through our RFQ form remain your property and are used solely for the purpose of preparing a quotation and, where applicable, fulfilling an order. Content on this website, including text, images and branding, is the property of M-Tech Engineering unless otherwise noted.</p>

    <h2>Limitation of Liability</h2>
    <p>Information on this website is provided for general reference. While we make reasonable efforts to keep it accurate and current, M-Tech Engineering makes no warranty as to completeness and is not liable for decisions made solely on the basis of website content, absent a formal quotation or agreement.</p>

    <h2>Changes to These Terms</h2>
    <p>We may update these terms from time to time. Continued use of this website after changes are posted constitutes acceptance of the revised terms.</p>

    <h2>Contact Us</h2>
    <p>Questions about these terms can be directed to <a href="mailto:info@mtechengineering.com" class="text-link">info@mtechengineering.com</a> or through our <a href="contact.php" class="text-link">contact page</a>.</p>

  </section>

</main>

<?php require_once __DIR__ . '/footer.php'; ?>
